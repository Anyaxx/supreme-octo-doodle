- Problem definition is incomplete
- We also need a source for which word appears in which context, to be able to infer this in the actual sentences.
- Once we have a set of strongly correlated words with each word-sense, we can search the context of a word in the target sentence.
- If there is a high overlap of those words with the already correlated words for a particular word sense, we can guess that that is the answer

