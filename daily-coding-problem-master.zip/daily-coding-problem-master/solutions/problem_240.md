I think, at the most, `n-1` moves should be sufficient. 
