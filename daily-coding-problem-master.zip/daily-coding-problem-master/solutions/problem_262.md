* For each edge
    * Disconnect it
    * Choose a random node and try to visit all other nodes
    * If not possible label the edge as a 'bridge'
